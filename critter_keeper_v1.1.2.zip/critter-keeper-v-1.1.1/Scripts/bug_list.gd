extends Control

# Array of bugs

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	name_bugs()
	#name()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

#var array1 = ["First", 2, 3, "Last"]
#func name():
	#print(array1[0])  # Prints "First"
	#print(array1[2])  # Prints 3
	#print(array1[-1]) # Prints "Last"
	
var array = ["Debug Bug"]

func name_bugs():
	print(array[0])  # Prints "Debug Bug"
