extends Node2D

@export var bug_amount: int = 0
@export var spawn_area: ColorRect 

func _ready():
	var bug_resource = load("res://Scene/Bug.tscn")
	
	if not spawn_area:
		return

	var area = spawn_area.get_global_rect()

	if has_node("Debug Bug"): 
		randomize_bug($"Debug Bug", area)

	for i in range(bug_amount - 1):
		var bug = bug_resource.instantiate()
		add_child(bug)
		randomize_bug(bug, area)

func randomize_bug(bug_node, area):
	var x = randf_range(area.position.x, area.position.x + area.size.x - 40)
	var y = randf_range(area.position.y, area.position.y + area.size.y - 40)
	bug_node.global_position = Vector2(x, y)
	bug_node.rotation = randf_range(0, TAU)
