@tool
extends Resource

class_name bug_tools

func _update_visuals_test():
	print("Attempting to load: ", current_bug)
	match current_bug:
		bug_types.MONARCH:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Monarch.png")
		bug_types.BEE:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Honey Bee.png")
		bug_types.BLUE_DASHER_DRAGONFLY:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Blue Dasher Dragonfly.png")
		bug_types.LADYBUG:
			bug_sprite = load("res://Assets/Bug Assets/Land Bugs/Ladybug.png")
		bug_types.HORNET:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Hornet.png")
		bug_types.PALMETTO_BUG:
			bug_sprite = load("res://Assets/Bug Assets/Land Bugs/Palmetto Bug.png")
		bug_types.LOVEBUG:
			bug_sprite = load("res://Assets/Bug Assets/Land Bugs/Love Bug.png")
		bug_types.GOLDEN_SILK_ORB_WEAVER:
			bug_sprite = load("res://Assets/Bug Assets/Special Bug/Golden Silk Orb Weaver.png")
		bug_types.DEBUG_BUG:
			bug_sprite = load("res://Assets/Bug Assets/Special Bug/Debug Bug Spritesheet.png")

	match current_behavior:
		behavior.strong:
			trait_accessory = load("res://Assets/Debug Assets/eraser_sprite.png")
		behavior.gay:
			trait_accessory = load("res://Assets/Debug Assets/icon.svg")

	if bug_sprite == null:
		print("FAILED: Could not find image at that path!")
	else:
		print("SUCCESS: Sprite loaded!")

enum bug_types {
	MONARCH,
	BLUE_DASHER_DRAGONFLY,
	BEE,
	LADYBUG,
	HORNET,
	PALMETTO_BUG,
	LOVEBUG,
	GOLDEN_SILK_ORB_WEAVER,
	DEBUG_BUG
};

@export var current_bug: bug_types:
	set(value):
		current_bug = value
		_update_visuals()

enum rarity {
	EVERYDAY_BUGGY,
	Barely_Noticed,
	Hidden_Gem,
	Local_Legend,
	Dont_Touch_It,
};

@export var current_rarity: rarity:
	set(value):
		current_rarity = value
		_update_visuals()

enum base {
	One = 1,
	Two = 2,
	Three = 3
};
@export var current_base: base

enum behavior {
	hyper,
	lazy,
	skittish,
	showman,
	strong,
	weak,
	gay,
	normal,
};

@export var current_behavior: behavior:
	set(value):
		current_behavior = value
		_update_visuals()

@export_group("Visuals")
@export var bug_sprite: Texture2D
@export var trait_accessory: Texture2D
@export var rarity_color: Color = Color.WHITE
@export var accessory_offset: Vector2

func _update_visuals():
	match current_bug:
		bug_types.MONARCH:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Monarch.png")
		bug_types.BEE:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Honey Bee.png")
		bug_types.BLUE_DASHER_DRAGONFLY:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Blue Dasher Dragonfly.png")
		bug_types.LADYBUG:
			bug_sprite = load("res://Assets/Bug Assets/Land Bugs/Ladybug.png")
		bug_types.HORNET:
			bug_sprite = load("res://Assets/Bug Assets/Flying Bugs/Hornet.png")
		bug_types.PALMETTO_BUG:
			bug_sprite = load("res://Assets/Bug Assets/Land Bugs/Palmetto Bug.png")
		bug_types.LOVEBUG:
			bug_sprite = load("res://Assets/Bug Assets/Land Bugs/Love Bug.png")
		bug_types.GOLDEN_SILK_ORB_WEAVER:
			bug_sprite = load("res://Assets/Bug Assets/Special Bug/Golden Silk Orb Weaver.png")
		bug_types.DEBUG_BUG:
			bug_sprite = load("res://Assets/Bug Assets/Special Bug/Debug Bug Spritesheet.png")

	match current_rarity:
		rarity.EVERYDAY_BUGGY:
			rarity_color = Color(1, 1, 1)
		rarity.Hidden_Gem:
			rarity_color = Color(0.4, 0.7, 1.0)
		rarity.Local_Legend:
			rarity_color = Color(2.5, 1.8, 0.0)
		rarity.Dont_Touch_It:
			rarity_color = Color(3.0, 0.0, 0.0)
		_:
			rarity_color = Color.WHITE

	match current_behavior:
		behavior.strong:
			trait_accessory = load("res://Assets/Debug Assets/eraser_sprite.png")
		behavior.gay:
			trait_accessory = load("res://Assets/Debug Assets/icon.svg")
		_:
			trait_accessory = null
