extends CharacterBody2D

@export var bug_data: bug_tools:
	set(value):
		bug_data = value
		if is_inside_tree():
			apply_bug_stats()

@onready var buggy_sprite = $Body
@onready var accessory_sprite = $Accessory

# Wander

@export var speed = 40
@export var change_chance = 0.3
@export var stop_chance = 0.05
@export var max_stop_time = 1.0
@export var tilt_amount = 0.5
@export var box_min = Vector2.ZERO
@export var box_max = Vector2(640, 480)

var target_direction = Vector2.RIGHT
var is_moving = true
var stop_timer = 0.0

func _ready():
	add_to_group("bug")
	if bug_data:
		apply_bug_stats()
		
		var type_name = bug_data.bug_types.keys()[bug_data.current_bug]
		var rarity_name = bug_data.rarity.keys()[bug_data.current_rarity]
		var behavior_name = bug_data.behavior.keys()[bug_data.current_behavior]
		
		print("This bug is a ", type_name, 
			", who has a base of ", bug_data.current_base, 
			". and is a ", rarity_name,
			", and acts ", behavior_name)
	
	target_direction = Vector2.RIGHT.rotated(randf() * TAU)
	global_position.x = clamp(global_position.x, box_min.x + 1, box_max.x - 1)
	global_position.y = clamp(global_position.y, box_min.y + 1, box_max.y - 1)

func apply_bug_stats():
	$Body.texture = bug_data.bug_sprite
	$Body.modulate = bug_data.rarity_color
	
	if bug_data.trait_accessory:
		$Accessory.texture = bug_data.trait_accessory
		$Accessory.position = bug_data.accessory_offset
		$Accessory.show()
	else:
		$Accessory.hide()

func _physics_process(delta):
	_handle_stopping(delta)
	_handle_direction()
	_handle_movement()
	_apply_tilt()

func _handle_stopping(delta):
	if stop_timer > 0.0:
		stop_timer -= delta
		is_moving = false
	else:
		if randf() < stop_chance:
			stop_timer = randf_range(0.1, max_stop_time)
		else:
			is_moving = true

func _handle_direction():
	if is_moving and randf() < change_chance:
		target_direction = target_direction.rotated(randf_range(-PI/4, PI/4)).normalized()
	
	if global_position.x <= box_min.x:
		target_direction.x = abs(target_direction.x)
	elif global_position.x >= box_max.x:
		target_direction.x = -abs(target_direction.x)
		
	if global_position.y <= box_min.y:
		target_direction.y = abs(target_direction.y)
	elif global_position.y >= box_max.y:
		target_direction.y = -abs(target_direction.y)

func _handle_movement():
	if is_moving:
		var wiggle = Vector2(randf_range(-0.2, 0.2), randf_range(-0.2, 0.2))
		velocity = (target_direction + wiggle).normalized() * speed
		move_and_slide()
		
		if get_slide_collision_count() > 0:
			var collision = get_slide_collision(0)
			target_direction = target_direction.bounce(collision.get_normal()).normalized()
	else:
		velocity = Vector2.ZERO

func _apply_tilt():
	if is_moving:
		buggy_sprite.rotation = tilt_amount * target_direction.x
		accessory_sprite.rotation = buggy_sprite.rotation
	else:
		buggy_sprite.rotation = move_toward(buggy_sprite.rotation, 0, 0.1)
		accessory_sprite.rotation = buggy_sprite.rotation
