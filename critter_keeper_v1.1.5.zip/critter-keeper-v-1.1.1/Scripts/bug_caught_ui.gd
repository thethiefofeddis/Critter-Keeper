extends CanvasLayer

@onready var sprite = $Panel/Sprite2D
@onready var name_label = $Panel/name_label
@onready var status_label = $Panel/status_label

func show_bug(caught_bug_data: bug_tools, is_new: bool):
	if not is_node_ready():
		await ready

	var type_name = caught_bug_data.bug_types.keys()[caught_bug_data.current_bug]
	var rarity_name = caught_bug_data.rarity.keys()[caught_bug_data.current_rarity]
	
	name_label.text = type_name + " Caught!"
	sprite.texture = caught_bug_data.bug_sprite
	sprite.modulate = caught_bug_data.rarity_color
	
	if is_new:
		status_label.text = "New Discovery! (" + rarity_name + ")"
	else:
		status_label.text = rarity_name
	
	await get_tree().create_timer(2).timeout
	queue_free()
