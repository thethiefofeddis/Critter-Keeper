extends Node2D

@export var available_bugs: Array[bug_tools]
@export var bug_amount: int = 5
@export var spawn_area: ColorRect 
@export var net_scene: PackedScene

var current_net = null

func _ready():
	randomize()
	var bug_resource = load("res://Scene/Debug Bug.tscn")
	
	if not spawn_area or available_bugs.is_empty():
		return

	var area = spawn_area.get_global_rect()

	for i in range(bug_amount):
		var bug = bug_resource.instantiate()
		
		# Create unique data for every bug
		var unique_data = available_bugs.pick_random().duplicate()
		unique_data.current_bug = randi() % 9 
		unique_data.current_rarity = randi() % 5 
		unique_data.current_behavior = randi() % 8 
		
		# Force texture load
		if unique_data.has_method("_update_visuals"):
			unique_data._update_visuals()
		
		# Use 'set' to avoid Node2D type errors
		bug.set("bug_data", unique_data)
		
		add_child(bug)
		randomize_bug(bug, area)

func randomize_bug(bug_node, area):
	var x = randf_range(area.position.x, area.position.x + area.size.x - 40)
	var y = randf_range(area.position.y, area.position.y + area.size.y - 40)
	bug_node.global_position = Vector2(x, y)
	bug_node.rotation = randf_range(0, TAU)

func _input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			# Safety check: only instantiate if net_scene is assigned
			if net_scene:
				current_net = net_scene.instantiate()
				add_child(current_net)
				current_net.global_position = get_global_mouse_position()
		else:
			if is_instance_valid(current_net):
				current_net.queue_free()
			current_net = null

func _process(_delta):
	# Use is_instance_valid to prevent the 'null instance' crash
	if is_instance_valid(current_net):
		current_net.global_position = get_global_mouse_position()
