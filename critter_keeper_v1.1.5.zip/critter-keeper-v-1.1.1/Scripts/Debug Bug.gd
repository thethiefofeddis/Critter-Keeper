extends CharacterBody2D

# Wander

@export var speed = 40
@export var change_chance = 0.3
@export var stop_chance = 0.05
@export var max_stop_time = 1.0
@export var tilt_amount = 0.5
@export var box_min = Vector2.ZERO
@export var box_max = Vector2(640, 480)

var target_direction = Vector2.RIGHT
var is_moving = true
var stop_timer = 0.0

@onready var sprite = $AnimatedSprite2D

func _ready():
	target_direction = Vector2.RIGHT.rotated(randf() * TAU)
	global_position.x = clamp(global_position.x, box_min.x + 1, box_max.x - 1)
	global_position.y = clamp(global_position.y, box_min.y + 1, box_max.y - 1)


func _physics_process(delta):
	_handle_stopping(delta)
	_handle_direction()
	_handle_movement()
	_apply_tilt()

func _handle_stopping(delta):
	if stop_timer > 0.0:
		stop_timer -= delta
		is_moving = false
	else:
		if randf() < stop_chance:
			stop_timer = randf_range(0.1, max_stop_time)
		else:
			is_moving = true

func _handle_direction():
	if is_moving and randf() < change_chance:
		target_direction = target_direction.rotated(randf_range(-PI/4, PI/4)).normalized()
	
	if global_position.x <= box_min.x:
		target_direction.x = abs(target_direction.x)
	elif global_position.x >= box_max.x:
		target_direction.x = -abs(target_direction.x)
		
	if global_position.y <= box_min.y:
		target_direction.y = abs(target_direction.y)
	elif global_position.y >= box_max.y:
		target_direction.y = -abs(target_direction.y)

func _handle_movement():
	if is_moving:
		var wiggle = Vector2(randf_range(-0.2, 0.2), randf_range(-0.2, 0.2))
		velocity = (target_direction + wiggle).normalized() * speed
		move_and_slide()
		
		if get_slide_collision_count() > 0:
			var collision = get_slide_collision(0)
			target_direction = target_direction.bounce(collision.get_normal()).normalized()
			
		sprite.play("walk")
	else:
		velocity = Vector2.ZERO
		sprite.play("idle")

func _apply_tilt():
	if is_moving:
		sprite.rotation = tilt_amount * target_direction.x / speed
	else:
		sprite.rotation = move_toward(sprite.rotation, 0, 0.1)



#func _input(event):
	#if event is InputEventMouseButton:
		#if event.button_index == event.pressed and MOUSE_BUTTON_LEFT:
			#if is_pixel_opaque(get_local_mouse_position()):
					#print ("clicked")
