extends ColorRect

# Time of day math and shaders, shaders will only be for grass as night is inside 

@export var hours_in_day: int = 12
@export var hours_in_night: int = 12
@export var seconds_per_hour: float = .5
@export var starting_hour: int = 6
@export var day_color: Color = Color(1, 1, 1)
@export var night_color: Color = Color(0.1, 0.1, 0.1)

var time_in_hours: float = 0
var total_day_length: float = 0

func _ready() -> void:
	total_day_length = hours_in_day + hours_in_night
	time_in_hours = fmod(starting_hour, total_day_length)

func _process(delta: float) -> void:
	time_in_hours += delta / seconds_per_hour
	time_in_hours = fmod(time_in_hours, total_day_length)
	var blend_factor: float = 0.0
	if time_in_hours < hours_in_day:
		var t = time_in_hours / hours_in_day
		blend_factor = sin(t * PI)
	else:
		var t = (time_in_hours - hours_in_day) / hours_in_night
		blend_factor = sin(t * PI)
	var final_tint = night_color.lerp(day_color, blend_factor)
	if material is ShaderMaterial:
		material.set_shader_parameter("tint_color", final_tint)

func get_current_hour() -> int:
	return int(time_in_hours)

func get_current_minute() -> int:
	return int((time_in_hours - int(time_in_hours)) * 60)

func is_daytime() -> bool:
	return time_in_hours < hours_in_day
