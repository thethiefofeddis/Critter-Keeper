extends Area2D

# catch bug with net
@export var lifetime := 0.2

func _ready():
	body_entered.connect(_on_body_entered)
	await get_tree().create_timer(lifetime).timeout
	queue_free()

func _on_body_entered(body):
	if body.is_in_group("bug"):
		print("caught bug")
		body.queue_free()
