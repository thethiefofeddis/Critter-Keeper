extends Area2D

@export var lifetime := 0.2
@export var bug_data: bug_tools
@onready var buggy_sprite = $Body
@onready var accessory_sprite = $Accessory

func _ready():
	# Connect to the body_entered signal
	body_entered.connect(_on_body_entered)
	
	# Self-destruct timer
	await get_tree().create_timer(lifetime).timeout
	queue_free()

# Inside your Net's _on_body_entered(body)
func _on_body_entered(body):
	if body.is_in_group("bug"):
		var ui = preload("res://Scene/BugCaughtUI.tscn").instantiate()
		get_tree().root.add_child(ui)
		
		# Pass the specific bug's data to the UI
		ui.show_bug(body.bug_data, true) 
		
		body.queue_free()
