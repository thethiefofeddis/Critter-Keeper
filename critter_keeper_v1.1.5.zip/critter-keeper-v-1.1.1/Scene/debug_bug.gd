extends Node2D

@export var available_bugs: Array[bug_tools]
@export var bug_amount: int = 5
@export var spawn_area: ColorRect 

func _ready():
	randomize()
	var bug_resource = load("res://Scene/Debug Bug.tscn")
	
	if not spawn_area or available_bugs.is_empty():
		return

	var area = spawn_area.get_global_rect()

	for i in range(bug_amount):
		var bug = bug_resource.instantiate()
		
		var unique_data = available_bugs.pick_random().duplicate()
		
		unique_data.current_rarity = randi() % unique_data.rarity.size()
		unique_data.current_behavior = randi() % unique_data.behavior.size()
		
		if "bug_data" in bug:
			bug.bug_data = unique_data
		else:
			push_error("The spawned scene does not have a bug_data variable!")
			
		add_child(bug)
		randomize_bug(bug, area)

func randomize_bug(bug_node, area):
	var x = randf_range(area.position.x, area.position.x + area.size.x - 40)
	var y = randf_range(area.position.y, area.position.y + area.size.y - 40)
	bug_node.global_position = Vector2(x, y)
	bug_node.rotation = randf_range(0, TAU)
